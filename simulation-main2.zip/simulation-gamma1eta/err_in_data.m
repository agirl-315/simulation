function error = err_in_data(sigama,gamma_1) 

numbers2=[105 71 110 136 128 131 151 175 129 164 175 167 173 186 186 185 204 242 201 232 230 224 222 207 212 227 235 243 260 281 299 305 343 277 323 341 282 374 282 310 346 377 401 375 392 400 411 411 418 449 455 449 470 426 411 370 383 380 447 548 520 519 533 581 559 571 592 579 620 612 607 651 612 638 682 662 677 657 713 727 711 718 731 778 755 755 773 794 781 856 912 ];

T=91;A=10;dt=0.1;
t=0:dt:T;
a=0:dt:A;

true_params =1.0e+02 *[   0.352515130115251   0.047015235822938   0.005661407793618   0.000003691126728 0.005455075565769   1.019771307504314   0.306606137197565   0.000000001070741 0.000000000019578   0.008502145965365   0.001182267556720   0.000383868123497 0.006890517];

 T0=true_params(1);
 I_T0=true_params(2) ;
V0=true_params(3);
betaa=true_params(4);
d=true_params(5);
p=true_params(6);
c=true_params(7);
 
beta_1=true_params(8);
%sigama=true_params(9);
eita=true_params(10);
lamada_1=true_params(11);
%gamma_1=true_params(12);
kesai=true_params(13);

K1=true_params(4:7);
[t1 Y]=ode45(@Model_l,a,[T0 I_T0 V0],[],K1);
Thealth = Y(:,1);
V = Y(:,3);
Lambda = 1859;
beta =true_params(8).*V;
sigama = sigama;
l = 7*10^(-4);
eita = true_params(10);
lamada =true_params(11).*Thealth; 
gamma = gamma_1.*V;
kesai = true_params(13);



S(1) = 2.95*10^6;
R(1) = 96;
W(1) = 120;
I(1,1)= 95; 
I1(1) = 95;



for n = 2:length(t)
    for j = 2:length(a)     
      I(n,j) = I(n-1,j-1)/(1+dt*(lamada(j)+l));   
      A(n,j)=  beta(j)*I(n,j)*dt;
      B(n,j) = lamada(j)*I(n,j)*dt;
      D(n,j) = gamma(j)*I(n,j)*dt;
      end
      A1(n)=sum(A(n,:))*dt;
      B1(n)=sum(B(n,:))*dt;
      D1(n)=sum(D(n,:))*dt;
    
      R(n) = (B1(n)+R(n-1))/(1+dt*(eita+l));
      W(n) = (D1(n)+W(n-1))/(1+kesai*dt);
      S(n) = (Lambda*dt+eita*dt*R(n)+S(n-1))/(1+A1(n)+dt*W(n-1)*sigama+l*dt);
      %I(n,1) =125;
      I(n,1) = S(n)*(A1(n)/dt+sigama*W(n));
    
    I1(n) = sum(I(n,:));
  
end

I2 = I1(1:10:901);
error = sum((numbers2 - I2).^2);
end





